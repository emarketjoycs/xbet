# 📝 Como Usar o Código Fonte Completo do DxBet

## 📦 O que Você Recebeu

**DxBet-Completo.zip** (5.9 MB) contém:

```
DxBet-Completo/
├── client/                          # Código React (Frontend)
│   ├── src/
│   │   ├── pages/                   # Páginas (Home, Dashboard, etc)
│   │   ├── components/              # Componentes (Header, Footer, etc)
│   │   ├── hooks/                   # Hooks customizados
│   │   ├── lib/                     # Configuração (Wagmi, Web3)
│   │   ├── contexts/                # Contextos (Tema)
│   │   ├── App.tsx                  # Roteador principal
│   │   ├── main.tsx                 # Entry point
│   │   └── index.css                # Estilos globais
│   ├── public/images/               # Imagens (logo, banner)
│   └── index.html                   # Template HTML
├── server/                          # Backend (placeholder)
├── shared/                          # Código compartilhado
├── dist/                            # Site compilado (pronto para publicar)
├── package.json                     # Dependências
├── vite.config.ts                   # Configuração Vite
├── tailwind.config.ts               # Configuração Tailwind
└── tsconfig.json                    # Configuração TypeScript
```

---

## 🚀 Instalação e Desenvolvimento

### Pré-requisitos
- Node.js 18+ (https://nodejs.org)
- pnpm (gerenciador de pacotes rápido)

### Passo 1: Extrair ZIP
```bash
unzip DxBet-Completo.zip
cd DxBet-Completo
```

### Passo 2: Instalar Dependências
```bash
npm install -g pnpm          # Instalar pnpm (se não tiver)
pnpm install                 # Instalar dependências do projeto
```

### Passo 3: Iniciar Servidor de Desenvolvimento
```bash
pnpm run dev
```

**Saída esperada:**
```
➜  Local:   http://localhost:5173/
➜  Network: http://192.168.x.x:5173/
```

Abra http://localhost:5173 no navegador!

---

## 📁 Estrutura de Arquivos Importantes

### Páginas (`client/src/pages/`)
| Arquivo | Descrição | Rota |
|---------|-----------|------|
| `Home.tsx` | Página inicial com hero section | `/` |
| `Dashboard.tsx` | Dashboard para usuários logados | `/dashboard` |
| `HowToBet.tsx` | Guia de como apostar | `/how-to-bet` |
| `Whitepaper.tsx` | Documentação técnica | `/whitepaper` |
| `NotFound.tsx` | Página 404 | `*` |

### Componentes (`client/src/components/`)
| Arquivo | Descrição |
|---------|-----------|
| `Header.tsx` | Cabeçalho com navegação e botão Connect Wallet |
| `Footer.tsx` | Rodapé com links |
| `ErrorBoundary.tsx` | Tratamento de erros |

### Hooks (`client/src/hooks/`)
| Arquivo | Descrição |
|---------|-----------|
| `useBettingContract.ts` | Hook para interagir com smart contract |
| `useComposition.ts` | Hook de composição |
| `useMobile.tsx` | Hook para detectar mobile |

### Configuração (`client/src/lib/`)
| Arquivo | Descrição |
|---------|-----------|
| `wagmi.ts` | Configuração Web3 (Wagmi + RainbowKit) |
| `utils.ts` | Funções utilitárias |

---

## 🔧 Modificar o Código

### Adicionar Nova Página
1. Criar arquivo em `client/src/pages/MinhaPage.tsx`:
```tsx
export default function MinhaPage() {
  return (
    <div>
      <h1>Minha Página</h1>
    </div>
  );
}
```

2. Adicionar rota em `client/src/App.tsx`:
```tsx
import MinhaPage from '@/pages/MinhaPage';

<Route path={"/minha-page"} component={MinhaPage} />
```

### Adicionar Novo Componente
1. Criar em `client/src/components/MeuComponente.tsx`
2. Importar em páginas:
```tsx
import MeuComponente from '@/components/MeuComponente';
```

### Modificar Estilos
Editar `client/src/index.css` para mudar cores, fontes, etc.

### Modificar Configuração Web3
Editar `client/src/lib/wagmi.ts` para:
- Adicionar outras redes (Polygon, Ethereum, etc)
- Mudar RPC endpoints
- Configurar WalletConnect Project ID

---

## 🔐 Configurar WalletConnect Project ID

**IMPORTANTE:** Sem isso, conexão com carteira não funciona!

### Passo 1: Obter Project ID
1. Acesse: https://cloud.walletconnect.com
2. Crie conta (grátis)
3. Crie novo projeto
4. Copie o **Project ID**

### Passo 2: Atualizar Configuração
Edite `client/src/lib/wagmi.ts`:

```typescript
export const config = getDefaultConfig({
  appName: 'DxBet - Decentralized Betting',
  projectId: 'SEU_PROJECT_ID_AQUI', // ← Cole aqui
  chains: [arbitrum],
  ssr: false,
});
```

### Passo 3: Reiniciar Servidor
```bash
pnpm run dev
```

---

## 🏗️ Compilar para Produção

### Build
```bash
pnpm run build
```

Isso cria a pasta `dist/public/` com os arquivos compilados.

### Preview
```bash
pnpm run preview
```

Testa o build localmente antes de publicar.

---

## 📤 Publicar em Netlify

### Opção 1: Deploy Manual
1. Acesse: https://app.netlify.com
2. Clique: "Add new site" → "Deploy manually"
3. Arraste a pasta `dist/public/` para upload
4. Pronto!

### Opção 2: Deploy Automático (GitHub)
1. Faça push do código para GitHub
2. Conecte repositório em Netlify
3. Configure:
   - Build command: `pnpm run build`
   - Publish directory: `dist/public`
4. Deploy automático a cada push!

---

## 🔍 Estrutura de Funções Principais

### `useBettingContract.ts`
Hook para interagir com smart contract:

```typescript
export function useBettingContract() {
  return {
    // Buscar saldo do usuário
    getUserBalance: async (address: string) => { ... },
    
    // Buscar apostas do usuário
    getUserBets: async (address: string) => { ... },
    
    // Colocar aposta
    placeBet: async (matchId: number, outcome: number, amount: string) => { ... },
    
    // Sacar ganhos
    claimWinnings: async (betId: number) => { ... }
  };
}
```

### `wagmi.ts`
Configuração Web3:

```typescript
export const config = getDefaultConfig({
  appName: 'DxBet',
  projectId: 'YOUR_PROJECT_ID',
  chains: [arbitrum],
  ssr: false,
});
```

---

## 🧪 Testar Localmente

### Teste 1: Verificar Compilação
```bash
pnpm run build
# Deve criar dist/public/ sem erros
```

### Teste 2: Verificar TypeScript
```bash
pnpm run check
# Deve passar sem erros
```

### Teste 3: Testar no Navegador
```bash
pnpm run dev
# Abrir http://localhost:5173
# Testar navegação e conexão com carteira
```

---

## 📚 Dependências Principais

| Pacote | Uso |
|--------|-----|
| `react` | Framework UI |
| `wagmi` | Interação com blockchain |
| `@rainbow-me/rainbowkit` | Conexão com carteira |
| `viem` | Biblioteca Web3 |
| `tailwindcss` | Estilos CSS |
| `shadcn/ui` | Componentes UI |
| `wouter` | Roteamento |

---

## 🐛 Troubleshooting

### Erro: "Cannot find module"
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Erro: "Port 5173 already in use"
```bash
pnpm run dev -- --port 3000
```

### Erro: "WalletConnect Project ID not found"
- Obtenha Project ID em https://cloud.walletconnect.com
- Atualize em `client/src/lib/wagmi.ts`

### Imagens não carregam
- Verifique se existem em `client/public/images/`
- Confirme paths em componentes (devem ser `/images/...`)

---

## 📝 Próximos Passos

### 1. Configurar WalletConnect
- Obtenha Project ID
- Atualize em `wagmi.ts`

### 2. Testar Localmente
```bash
pnpm install
pnpm run dev
```

### 3. Integrar Smart Contract
- Atualize `useBettingContract.ts` com funções reais
- Teste transações

### 4. Publicar
```bash
pnpm run build
# Upload dist/public/ para Netlify
```

---

## 💡 Dicas

- Use `pnpm` em vez de `npm` (mais rápido)
- Edite `index.css` para mudar tema
- Componentes estão em `components/ui/`
- Páginas estão em `pages/`
- Hooks customizados em `hooks/`

---

**Versão:** 1.0  
**Data:** Dezembro 2024  
**Status:** ✅ Pronto para Desenvolvimento
